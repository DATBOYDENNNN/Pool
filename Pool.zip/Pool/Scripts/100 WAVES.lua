-- LocalScript
local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local VirtualUser = game:GetService("VirtualUser")

local player = Players.LocalPlayer
local pGui = player:WaitForChild("PlayerGui")

-- State Management
local menuVisible = true
local espEnabled = false
local autoDeleteEnabled = false
local farmEnabled = false
local godModeEnabled = false
local highlights = {}
local lastSafePos = nil

-- UI Creation
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "SilentImGui"
ScreenGui.Parent = pGui
ScreenGui.ResetOnSpawn = false

local MainFrame = Instance.new("Frame")
MainFrame.Size = UDim2.new(0, 400, 0, 450)
MainFrame.Position = UDim2.new(1, -420, 1, -500)
MainFrame.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
MainFrame.BorderSizePixel = 1
MainFrame.BorderColor3 = Color3.fromRGB(60, 60, 60)
MainFrame.Active = true
MainFrame.Parent = ScreenGui

-- Header
local TopBar = Instance.new("Frame")
TopBar.Size = UDim2.new(1, 0, 0, 25)
TopBar.BackgroundColor3 = Color3.fromRGB(40, 40, 50)
TopBar.BorderSizePixel = 0
TopBar.Parent = MainFrame

local Title = Instance.new("TextLabel")
Title.Size = UDim2.new(1, -30, 1, 0)
Title.Position = UDim2.new(0, 10, 0, 0)
Title.Text = "Silent - ImGui [F3]"
Title.TextColor3 = Color3.new(1, 1, 1)
Title.TextXAlignment = Enum.TextXAlignment.Left
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 16
Title.BackgroundTransparency = 1
Title.Parent = TopBar

-- F3 Toggle
UserInputService.InputBegan:Connect(function(input, gpe)
    if not gpe and input.KeyCode == Enum.KeyCode.F3 then
        menuVisible = not menuVisible
        MainFrame.Visible = menuVisible
    end
end)

-- Checkbox Helper
local function createCheckbox(text, yPos, callback)
	local container = Instance.new("Frame", MainFrame)
	container.Size = UDim2.new(0.9, 0, 0, 30)
	container.Position = UDim2.new(0.05, 0, 0, yPos)
	container.BackgroundTransparency = 1
	local box = Instance.new("TextButton", container)
	box.Size = UDim2.new(0, 18, 0, 18)
	box.BackgroundColor3 = Color3.fromRGB(40, 40, 45)
	box.Text = ""
	local label = Instance.new("TextLabel", container)
	label.Size = UDim2.new(1, -30, 1, 0)
	label.Position = UDim2.new(0, 28, 0, 0)
	label.Text = text
	label.TextColor3 = Color3.fromRGB(200, 200, 200)
	label.BackgroundTransparency = 1
	label.TextXAlignment = "Left"
	local active = false
	box.MouseButton1Click:Connect(function()
		active = not active
		box.BackgroundColor3 = active and Color3.fromRGB(0, 150, 255) or Color3.fromRGB(40, 40, 45)
		box.Text = active and "✓" or ""
		callback(active)
	end)
end

-- UI Setup
createCheckbox("ESP Outlines", 50, function(v) espEnabled = v end)
createCheckbox("Delete Entrances", 90, function(v) autoDeleteEnabled = v end)
createCheckbox("GOD MODE (Immortal)", 130, function(v) godModeEnabled = v end)
createCheckbox("STABLE UNDER-FOOT FARM", 170, function(v) 
    farmEnabled = v 
    if not v and player.Character then
        local hrp = player.Character:FindFirstChild("HumanoidRootPart")
        local hum = player.Character:FindFirstChild("Humanoid")
        if hrp then hrp.Anchored = false end
        if hum then hum.PlatformStand = false end
    end
end)

-- Zombie Finder
local function getClosestZombie()
    local closest = nil
    local dist = math.huge
    local folders = {Workspace:FindFirstChild("Zombies"), Workspace:FindFirstChild("ServerZombies")}
    for _, f in pairs(folders) do
        if f then
            for _, z in pairs(f:GetChildren()) do
                local hrp = z:FindFirstChild("HumanoidRootPart") or z:FindFirstChild("Torso")
                local hum = z:FindFirstChildOfClass("Humanoid")
                if hrp and hum and hum.Health > 0 then
                    if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
                        local d = (player.Character.HumanoidRootPart.Position - hrp.Position).Magnitude
                        if d < dist then dist = d; closest = z end
                    end
                end
            end
        end
    end
    return closest
end

-- Loop Logic
RunService.Heartbeat:Connect(function()
    -- GOD MODE LOGIC
    if godModeEnabled and player.Character then
        local hum = player.Character:FindFirstChildOfClass("Humanoid")
        if hum then
            hum.Health = hum.MaxHealth
            -- Prevent death states
            if hum:GetState() == Enum.HumanoidStateType.Dead then
                hum:ChangeState(Enum.HumanoidStateType.GettingUp)
            end
        end
        -- Remove damage scripts if the game uses them
        for _, v in pairs(player.Character:GetDescendants()) do
            if v:IsA("Script") and (v.Name:lower():find("damage") or v.Name:lower():find("kill")) then
                v.Disabled = true
            end
        end
    end

    -- AUTO FARM LOGIC
    if farmEnabled and player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
        local target = getClosestZombie()
        local myRoot = player.Character.HumanoidRootPart
        local myHum = player.Character:FindFirstChild("Humanoid")

        if target then
            local hrp = target:FindFirstChild("HumanoidRootPart") or target:FindFirstChild("Torso")
            local hum = target:FindFirstChildOfClass("Humanoid")
            
            if hrp and hum then
                myRoot.Anchored = true
                if myHum then myHum.PlatformStand = true end
                myRoot.Velocity = Vector3.new(0, 0, 0)
                
                -- Stay under feet but close enough to hit
                player.Character:PivotTo(hrp.CFrame * CFrame.new(0, -4.5, 0) * CFrame.Angles(math.rad(90), 0, 0))
                lastSafePos = hrp.Position + Vector3.new(0, 20, 0)

                -- Fast Click
                VirtualUser:CaptureController()
                VirtualUser:Button1Down(Vector2.new(0,0), Workspace.CurrentCamera.CFrame)
                task.wait(0.01)
                VirtualUser:Button1Up(Vector2.new(0,0), Workspace.CurrentCamera.CFrame)

                -- Auto Equip
                local tool = player.Backpack:FindFirstChildOfClass("Tool") or player.Character:FindFirstChildOfClass("Tool")
                if tool and tool.Parent ~= player.Character then tool.Parent = player.Character end
            end
        else
            -- No targets: Fly High
            if lastSafePos then
                player.Character:PivotTo(CFrame.new(lastSafePos))
            else
                player.Character:PivotTo(myRoot.CFrame * CFrame.new(0, 50, 0))
            end
            myRoot.Anchored = true
            if myHum then myHum.PlatformStand = false end
        end
    end
end)