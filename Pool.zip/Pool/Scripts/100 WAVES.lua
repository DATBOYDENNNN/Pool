-- LocalScript
local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local VirtualUser = game:GetService("VirtualUser")
local Lighting = game:GetService("Lighting")

local player = Players.LocalPlayer
local pGui = player:WaitForChild("PlayerGui")

-- State Management
local espEnabled, farmEnabled, godModeEnabled, antiLagEnabled, autoDeleteEnabled = false, false, false, false, false
local highlights = {}
local lastSafePos = nil

-- UI Setup
local ScreenGui = Instance.new("ScreenGui", pGui)
ScreenGui.Name = "SilentUltimate"
ScreenGui.ResetOnSpawn = false

local MainFrame = Instance.new("Frame", ScreenGui)
MainFrame.Size = UDim2.new(0, 380, 0, 480)
MainFrame.Position = UDim2.new(0.5, -190, 0.5, -240)
MainFrame.BackgroundColor3 = Color3.fromRGB(20, 20, 25)
MainFrame.BorderSizePixel = 0

local Title = Instance.new("TextLabel", MainFrame)
Title.Size = UDim2.new(1, 0, 0, 35)
Title.Text = "SILENT ULTIMATE - [F3]"
Title.TextColor3 = Color3.new(1, 1, 1)
Title.BackgroundColor3 = Color3.fromRGB(30, 30, 40)
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 18

-- UI Helper
local function createToggle(text, y, callback)
    local btn = Instance.new("TextButton", MainFrame)
    btn.Size = UDim2.new(0.9, 0, 0, 40)
    btn.Position = UDim2.new(0.05, 0, 0, y)
    btn.BackgroundColor3 = Color3.fromRGB(45, 45, 55)
    btn.Text = text .. ": OFF"
    btn.TextColor3 = Color3.new(1, 1, 1)
    btn.Font = Enum.Font.SourceSans
    btn.TextSize = 16
    local active = false
    btn.MouseButton1Click:Connect(function()
        active = not active
        btn.Text = text .. (active and ": ON" or ": OFF")
        btn.BackgroundColor3 = active and Color3.fromRGB(0, 150, 255) or Color3.fromRGB(45, 45, 55)
        callback(active)
    end)
end

-- Keybind Toggle
UserInputService.InputBegan:Connect(function(input, gpe)
    if not gpe and input.KeyCode == Enum.KeyCode.F3 then MainFrame.Visible = not MainFrame.Visible end
end)

-- Feature Toggles
createToggle("God Mode (Immortal)", 50, function(v) godModeEnabled = v end)
createToggle("Auto Farm (Under-Foot)", 100, function(v) 
    farmEnabled = v 
    if not v and player.Character then 
        local hrp = player.Character:FindFirstChild("HumanoidRootPart")
        if hrp then hrp.Anchored = false end
    end
end)
createToggle("Zombie ESP Outlines", 150, function(v) espEnabled = v end)
createToggle("Delete Entrances", 200, function(v) autoDeleteEnabled = v end)
createToggle("Anti-Lag (FPS Boost)", 250, function(v) 
    antiLagEnabled = v 
    Lighting.GlobalShadows = not v
end)

-- Helper: Get All Zombies from specific folders
local function getZombies()
    local list = {}
    local targets = {Workspace:FindFirstChild("Zombies"), Workspace:FindFirstChild("ServerZombies")}
    for _, f in pairs(targets) do
        if f then for _, z in pairs(f:GetChildren()) do table.insert(list, z) end end
    end
    return list
end

-- MASTER LOOP
task.spawn(function()
    while task.wait() do
        local char = player.Character
        if not char then continue end
        local hum = char:FindFirstChildOfClass("Humanoid")
        local hrp = char:FindFirstChild("HumanoidRootPart")

        -- 1. GOD MODE
        if godModeEnabled and hum then
            hum.Health = hum.MaxHealth
            if hum:GetState() == Enum.HumanoidStateType.Dead then
                hum:ChangeState(Enum.HumanoidStateType.GettingUp)
            end
        end

        -- 2. AUTO FARM
        if farmEnabled and hrp and hum then
            local zombies = getZombies()
            local target = nil
            local dist = math.huge

            for _, z in pairs(zombies) do
                local zhrp = z:FindFirstChild("HumanoidRootPart")
                local zhum = z:FindFirstChildOfClass("Humanoid")
                if zhrp and zhum and zhum.Health > 0 then
                    local d = (hrp.Position - zhrp.Position).Magnitude
                    if d < dist then dist = d; target = z end
                end
            end

            if target then
                local tr = target.HumanoidRootPart
                hrp.Anchored = true
                hum.PlatformStand = true
                
                -- Teleport under feet (4.5 studs) looking up
                char:PivotTo(tr.CFrame * CFrame.new(0, -4.5, 0) * CFrame.Angles(math.rad(90), 0, 0))
                lastSafePos = tr.Position + Vector3.new(0, 20, 0)

                -- Click and Equip
                VirtualUser:CaptureController()
                VirtualUser:Button1Down(Vector2.new(0,0))
                local tool = player.Backpack:FindFirstChildOfClass("Tool")
                if tool then tool.Parent = char end
            else
                -- NO ZOMBIES: Safe Sky Anchor
                if lastSafePos then
                    char:PivotTo(CFrame.new(lastSafePos))
                else
                    char:PivotTo(hrp.CFrame * CFrame.new(0, 50, 0))
                end
                hrp.Anchored = true
                hum.PlatformStand = false
                VirtualUser:Button1Up(Vector2.new(0,0))
            end
        end
    end
end)

-- SECONDARY LOOP (Visuals & Map)
RunService.Heartbeat:Connect(function()
    -- ESP Logic
    if espEnabled then
        for _, z in pairs(getZombies()) do
            if not highlights[z] then
                local h = Instance.new("Highlight", z)
                h.FillTransparency = 0.5
                h.OutlineColor = Color3.new(1, 0, 0)
                highlights[z] = h
            end
        end
    end

    -- Entrance Logic
    if autoDeleteEnabled then
        for _, obj in pairs(Workspace:GetDescendants()) do
            if obj.Name == "ZombieEntrance" then
                obj:ClearAllChildren()
            end
        end
    end
end)